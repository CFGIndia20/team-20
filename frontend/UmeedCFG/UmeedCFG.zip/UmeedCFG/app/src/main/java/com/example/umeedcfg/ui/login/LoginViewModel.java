package com.example.umeedcfg.ui.login;

public class LoginViewModel {
}
